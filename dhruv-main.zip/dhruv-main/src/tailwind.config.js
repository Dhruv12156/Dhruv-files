module.exports = {
  darkMode: 'class',
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        lavender: {
          100: '#F5F3FF',
          200: '#EDE9FE',
          300: '#DDD6FE',
          400: '#C4B5FD',
          500: '#8B5CF6',
          600: '#7E6BC4',
          700: '#6D5BB7',
          800: '#5C4A9A',
        },
        teal: {
          100: '#CCFBF1',
          200: '#99F6E4',
          300: '#5EEAD4',
          400: '#2DD4BF',
          500: '#14B8A6',
          600: '#0D9488',
          700: '#0F766E',
          800: '#115E59',
          900: '#134E4A',
        }
      },
      animation: {
        'float': 'float 3s ease-in-out infinite',
        'soft-pulse': 'pulse 5s cubic-bezier(0.4, 0, 0.6, 1) infinite', // Added softer pulse
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-10px)' },
        }
      },
      backdropBlur: {
        xs: '2px',
        sm: '4px',
      }
    },
  },
  plugins: [],
}
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Projects from './components/Projects';
import Contact from './components/Contact';
import Footer from './components/Footer';

function App() {
  const [darkMode, setDarkMode] = useState(false);

  return (
    <div className={darkMode ? 'dark' : ''}>
      <div className="min-h-screen bg-white dark:bg-gray-900 transition-colors duration-300">
        <Navbar darkMode={darkMode} setDarkMode={setDarkMode} />
        <main className="mx-auto px-4 sm:px-6 lg:px-8 max-w-7xl">
          <AnimatePresence>
            <Hero />
            <About />
            <Projects />
            <Contact />
          </AnimatePresence>
        </main>
        <Footer />
      </div>
    </div>
  );
}

export default App;
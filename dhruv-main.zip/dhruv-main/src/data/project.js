export const projects = [
  {
    id: 1,
    title: "K8 Cloud Monitoring",
    description: "A full-stack DevOps-based monitoring application built using Python (Flask) for the backend, containerized with Docker, and orchestrated using Kubernetes. The application provides real-time monitoring and visualization features, following modern CI/CD and deployment practices.",
    tags: ["K8", "Docker", "Flask", "AWS"],
    image: "https://docs.docker.com/get-started/images/docker-architecture.webp", 
    githubLink: "https://github.com/Dhruv12156/cloud-native-monitoring-app",
    liveLink: ""
  },
  {
    id: 2,
    title: "Portfolio App",
    description: "A personal portfolio application showcasing my skills in React, Tailwind CSS, and cloud deployment. The project is fully responsive and deployed on Vercel, demonstrating frontend development and cloud hosting expertise.",
    tags: ["Vercel", "React", "Framer-Motion", "Tailwind CSS"],
    image: "https://img.freepik.com/free-vector/hand-drawn-web-developers_23-2148819604.jpg?semt=ais_hybrid&w=740",
    githubLink: "https://github.com/Dhruv12156/Dhruv-files",
    liveLink: ""
  },


    {
    id: 3,
    title: "Contribution",
    description: "Contributed to multiple team projects by containerizing applications using Docker, streamlining deployment and enhancing development workflows.",
    tags: ["Docker"],
    image: "https://www.digitalogy.co/blog/wp-content/uploads/2021/08/open-Source-1.png",
    githubLink: "https://github.com/docker",
    liveLink: ""
  }
];

import { motion } from 'framer-motion';
import { FiMoon, FiSun, FiGithub, FiLinkedin, FiMenu, FiDownload } from 'react-icons/fi';
import { useState } from 'react';

const Navbar = ({ darkMode, setDarkMode }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const navItems = [
    { name: 'About', href: '#about' },
    { name: 'Projects', href: '#projects' },
    { name: 'Contact', href: '#contact' },
  ];

  const handleDownloadResume = () => {

  const resumeUrl = '/dhruv.pdf';
  const link = document.createElement('a');
  link.href = resumeUrl;
  link.download = 'Dhruv_Resume.pdf';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

  return (
    <motion.nav 
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="py-6 px-6 sm:px-8 flex justify-between items-center bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm border-b border-gray-100 dark:border-gray-800"
    >
      <a 
        href="#" 
        className="text-xl font-bold text-gray-800 dark:text-gray-100 hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
      >
        Folio
      </a>
      
      {/* Desktop Navigation */}
      <div className="hidden md:flex items-center space-x-8">
        {navItems.map((item) => (
          <motion.a 
            key={item.name}
            href={item.href}
            whileHover={{ y: -2 }}
            className="text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 transition-colors font-medium"
          >
            {item.name}
          </motion.a>
        ))}
        
        {/* Resume Download Button - Desktop */}
        <motion.button
          onClick={handleDownloadResume}
          whileHover={{ y: -2 }}
          className="flex items-center space-x-2 bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-md transition-colors"
        >
          <FiDownload size={16} />
          <span>Resume</span>
        </motion.button>
      </div>

      {/* Mobile Menu Button */}
      <div className="flex items-center space-x-4 md:hidden">
        <button 
          onClick={handleDownloadResume}
          className="text-gray-500 dark:text-gray-400"
          aria-label="Download resume"
        >
          <FiDownload size={20} />
        </button>
        <button 
          className="text-gray-500 dark:text-gray-400"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          aria-label="Toggle menu"
        >
          <FiMenu size={24} />
        </button>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="md:hidden absolute top-20 right-6 bg-white dark:bg-gray-800 shadow-lg rounded-lg p-4 z-50 border border-gray-100 dark:border-gray-700"
        >
          <div className="flex flex-col space-y-4">
            {navItems.map((item) => (
              <a 
                key={item.name}
                href={item.href}
                className="text-gray-700 dark:text-gray-200 hover:text-gray-900 dark:hover:text-white px-4 py-2 rounded transition-colors"
                onClick={() => setMobileMenuOpen(false)}
              >
                {item.name}
              </a>
            ))}
            {/* Resume Download Button - Mobile */}
            <button
              onClick={() => {
                handleDownloadResume();
                setMobileMenuOpen(false);
              }}
              className="flex items-center justify-center space-x-2 bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-md transition-colors"
            >
              <FiDownload size={16} />
              <span>Download Resume</span>
            </button>
          </div>
        </motion.div>
      )}
    </motion.nav>
  );
};

export default Navbar;
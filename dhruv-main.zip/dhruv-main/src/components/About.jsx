import { motion } from 'framer-motion';

const About = () => {
  const skills = [
    'AWS S3', 'EC2', 'Docker', 'Git', 
    'Github'
  ];

  return (
    <section id="about" className="py-20">
      <div className="max-w-6xl mx-auto">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-3xl font-bold text-gray-900 dark:text-white mb-12 text-center"
        >
          About Me
        </motion.h2>
        
        <div className="flex flex-col md:flex-row gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="md:w-1/3 flex justify-center"
          >
            <div className="w-64 h-64 rounded-full bg-indigo-100 dark:bg-indigo-900/30 overflow-hidden border-4 border-indigo-200 dark:border-indigo-800">
              {/* Replace with your image */}
              <div className="w-full h-full bg-gray-300 dark:bg-gray-700 flex items-center justify-center">
                <img src='https://img.freepik.com/free-vector/programming-concept-illustration_114360-1351.jpg?semt=ais_hybrid&w=740'></img>
              </div>
            </div>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="md:w-2/3"
          >
            <h3 className="text-xl font-semibold text-gray-800 dark:text-white mb-4">
              Who am I?
            </h3>
            <p className="text-gray-600 dark:text-gray-300 mb-6">
              I'm a passionate cloud engineer with expertise in building exceptional digital experiences. 
              With a strong foundation in computer science and years of hands-on experience, 
              I specialize in creating efficient, scalable, and user-friendly solutions.
            </p>
            <p className="text-gray-600 dark:text-gray-300 mb-6">
              When I'm not so active, you can find me exploring new technologies, contributing to 
              open-source projects, or enjoying outdoor activities.
            </p>
            
            <div>
              <h4 className="text-lg font-medium text-gray-800 dark:text-white mb-4">
                My Skills
              </h4>
              <div className="flex flex-wrap gap-3">
                {skills.map((skill, index) => (
                  <motion.span
                    key={skill}
                    initial={{ opacity: 0, scale: 0.8 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.3, delay: index * 0.05 }}
                    className="px-4 py-2 bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-300 rounded-full text-sm"
                  >
                    {skill}
                  </motion.span>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default About;
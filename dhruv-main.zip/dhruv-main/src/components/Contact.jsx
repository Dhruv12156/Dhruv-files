import { motion } from 'framer-motion';
import { FiMail, FiMapPin, FiGithub, FiLinkedin, FiTwitter } from 'react-icons/fi';

const Contact = () => {
  return (
    <section id="contact" className="py-20 bg-gray-50 dark:bg-gray-900">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-4">
            Get In Touch
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            Feel free to reach out if you're looking for a collaborator, have a question, or just want to connect.
          </p>
        </motion.div>

        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl overflow-hidden">
          <div className="grid md:grid-cols-2">
            {/* Contact Information */}
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="p-10 bg-gradient-to-br from-indigo-500 to-purple-600 text-white"
            >
              <h3 className="text-2xl font-bold mb-8">Contact Information</h3>
              
              <div className="space-y-6">
                <div className="flex items-start">
                  <div className="flex-shrink-0 bg-white/10 p-3 rounded-lg">
                    <FiMail className="h-6 w-6" />
                  </div>
                  <div className="ml-4">
                    <h4 className="text-lg font-semibold">Email</h4>
                    <a href="mailto:your.email@example.com" className="text-indigo-100 hover:text-white transition">
                      dhruvnarayanm676@gmail.com
                    </a>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="flex-shrink-0 bg-white/10 p-3 rounded-lg">
                    <FiMapPin className="h-6 w-6" />
                  </div>
                  <div className="ml-4">
                    <h4 className="text-lg font-semibold">Location</h4>
                    <p className="text-indigo-100">Jalandhar, Punjab</p>
                  </div>
                </div>
              </div>

              {/* Social Links */}
              <div className="mt-12">
                <h4 className="text-lg font-semibold mb-4">Follow Me</h4>
                <div className="flex space-x-4">
                  <motion.a 
                    whileHover={{ y: -2 }}
                    href="https://github.com/Dhruv12156" 
                    className="bg-white/10 p-3 rounded-lg hover:bg-white/20 transition"
                    aria-label="GitHub"
                  >
                    <FiGithub className="h-5 w-5" />
                  </motion.a>
                  <motion.a 
                    whileHover={{ y: -2 }}
                    href="https://surl.li/vbwlie" 
                    className="bg-white/10 p-3 rounded-lg hover:bg-white/20 transition"
                    aria-label="LinkedIn"
                  >
                    <FiLinkedin className="h-5 w-5" />
                  </motion.a>
                </div>
              </div>
            </motion.div>

            {/* Visual Element (Replacing Form) */}
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="p-10 flex items-center justify-center bg-white dark:bg-gray-800"
            >
              <div className="text-center">
                <div className="mx-auto mb-8 w-48 h-48 bg-gradient-to-br from-indigo-100 to-purple-100 dark:from-gray-700 dark:to-gray-800 rounded-full flex items-center justify-center">
                  <motion.div
                    animate={{ 
                      scale: [1, 1.05, 1],
                      rotate: [0, 5, -5, 0]
                    }}
                    transition={{ 
                      duration: 4,
                      repeat: Infinity,
                      repeatType: "reverse"
                    }}
                    className="text-6xl text-indigo-600 dark:text-indigo-400"
                  >
                    👋
                  </motion.div>
                </div>
                <h3 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">
                  Let's Connect!
                </h3>
                <p className="text-gray-600 dark:text-gray-300 mb-6">
                  Reach out via email or connect with me on social media.
                </p>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
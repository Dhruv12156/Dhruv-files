import { motion } from 'framer-motion';
import { FiGithub, FiLinkedin, FiTwitter } from 'react-icons/fi';

const Footer = () => {
  return (
    <motion.footer
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
      className="py-8 border-t border-gray-200 dark:border-gray-700"
    >
      <div className="max-w-6xl mx-auto px-4 flex flex-col md:flex-row justify-center items-center">
        <p className="text-gray-600 dark:text-gray-300 mb-4 md:mb-0">
          © {new Date().getFullYear()} Your Name. All rights reserved.
        </p>
      </div>
    </motion.footer>
  );
};

export default Footer;